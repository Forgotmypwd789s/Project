## Notes APP

---

> This is a simple Notes Application

### How To Setup

- `yarn install`
- `yarn start` || `yarn run dev`

> The project will start locally at localhost:8085

### API Endpoints

---

- GET /notes
- POST /add-note
- DELETE /delete-note/{:id}
